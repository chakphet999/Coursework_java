package Zoo;

public class Animal {
    private String name;
    private int age;

    public Animal(String name,int age){
        this.name = name;
        this.age = age;
    }
    public String getName(){
        return this.name;
    }
    public int getAge(){
        return this.age;
    }
    public void makeSound(){
        System.out.println("Animal makes a sound");
    System.out.println(toString());
    }
    public String toString(){
        return "Name : "+name+" Age : "+age;
    }
}
